package com.jsp.Paymentwallet.dto;

import lombok.Data;

@Data
public class Login {
	private String email;
	private String password;
}
